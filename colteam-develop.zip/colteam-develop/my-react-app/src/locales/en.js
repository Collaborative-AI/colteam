export default {
    hello: `hello`,
};