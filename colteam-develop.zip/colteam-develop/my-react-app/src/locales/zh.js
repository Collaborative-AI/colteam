export default {
    hello: `你好`,
    projectSearch: '搜索你的项目',
    projectCreate: '创建项目',
    projectTop: '热门项目/最受好评：',
    sort: '排序规则'
  };