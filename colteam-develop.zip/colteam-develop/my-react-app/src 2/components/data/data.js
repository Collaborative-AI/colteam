import React, { Component } from 'react'
export default class Data extends Component {
  render () {
    return (
      <div className="auth-inner-large">
        <h3>Data</h3>
      </div>
    )
  }
}