import React, { Component } from 'react'
export default class Team extends Component {
  render () {
    return (

      <div className="auth-inner-large">
        <h3>Team</h3>
      </div>
    )
  }
}