from django.contrib import admin
from .models import ProjectDetail

# Register your models here.
admin.site.register(ProjectDetail)